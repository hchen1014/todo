<!DOCTYPE html>
<html>
  <head>
    <title>ToDo List</title>
    <link rel='stylesheet' href='./stylesheets/style.css' />
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/fontawesome-all.css">
  </head>
  <body>